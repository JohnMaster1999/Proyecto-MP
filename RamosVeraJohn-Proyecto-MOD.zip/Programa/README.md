# Proyecto-MP
Repositorio para el proyecto del cuaderno digital para la asinatura de Metodología de la Programación.
Integrantes:
-Pablo ArQuellada Cebrian
-Manuel Candil Baeza
-Juan Repeto Deudero
-John Michaell Ramos Vera
