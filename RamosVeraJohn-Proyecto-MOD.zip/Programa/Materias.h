#ifndef MATERIAS_H
#define MATERIAS_H


typedef struct Materias
{
	int Id_materia;
	char Nombre_Materia[51];
	char Abrev_materia[4];
}Materias;

#endif
