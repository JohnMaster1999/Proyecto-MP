#ifndef __HORARIOS_H
#define __HORARIOS_H

typedef struct
{
  int Id_Profesor;
  int Dia_Clase;
  int Hora_Clase;
  int Id_materia;
  char Grupo[11];
} Horarios;

#endif
