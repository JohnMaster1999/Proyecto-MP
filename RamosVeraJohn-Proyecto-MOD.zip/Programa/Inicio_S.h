#ifndef Inicio_S
#define Inicio_S

#include "Usuarios.h"

//Cabecera: int inicio(Usuarios*, int).
//Precondición: recibe la estructura usuarios y en número de usuarios.
//Postcondición: devuelve la posición en el vector de usuarios.
int inicio(Usuarios*, int);

#endif // INICIO_S
