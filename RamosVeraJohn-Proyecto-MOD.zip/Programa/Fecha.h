#ifndef FECHA_H
#define FECHA_H

typedef struct Fecha
{
    int dia, mes, anio;
}Fecha;


#endif
